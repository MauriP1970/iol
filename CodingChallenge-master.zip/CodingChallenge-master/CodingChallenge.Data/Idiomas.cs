﻿namespace CodingChallenge.Data
{
    /// <summary>
    /// Definiciones de idiomas
    /// </summary>
    public static class Idiomas
    {
        public static readonly string Castellano = "es";
        public static readonly string Ingles = "en";
    }
}
