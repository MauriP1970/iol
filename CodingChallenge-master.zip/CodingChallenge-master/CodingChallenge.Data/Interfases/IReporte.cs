﻿using System.Collections.Generic;

namespace CodingChallenge.Data.Interfases
{
    public interface IReporte
    {
        string Imprimir(List<IFormaGeometrica> formas, string idioma);
    }
}
