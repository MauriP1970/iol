﻿namespace CodingChallenge.Data.Interfases
{
    public interface IFormaGeometrica
    {
        string Nombre { get; }

        decimal CalcularArea();
        decimal CalcularPerimetro();
    }
}
