﻿namespace CodingChallenge.Data.Interfases
{
    public interface ITraductor
    {
        string TraducirForma(string nombreForma, int cantidad, string idioma);
        string TraducirReporte(string tag, string idioma);
    }
}
