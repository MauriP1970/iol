﻿using CodingChallenge.Data.Interfases;
using System;

namespace CodingChallenge.Data.Implementacion.Formas
{
    public class Circulo : BaseFormaGeometrica
    {
        private readonly decimal _lado;

        public Circulo(decimal ancho)
        {
            _lado = ancho;
        }

        public override decimal CalcularArea() => (decimal)Math.PI * (_lado / 2) * (_lado / 2);

        public override decimal CalcularPerimetro() => (decimal)Math.PI * _lado;
    }
}
