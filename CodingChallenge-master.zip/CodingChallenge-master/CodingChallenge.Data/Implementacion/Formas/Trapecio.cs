﻿using CodingChallenge.Data.Interfases;

namespace CodingChallenge.Data.Implementacion.Formas
{
    public class Trapecio : BaseFormaGeometrica
    {
        private readonly decimal _a;
        private readonly decimal _b;
        private readonly decimal _c;
        private readonly decimal _d;
        private readonly decimal _h;

        public Trapecio(decimal a, decimal b, decimal c, decimal d, decimal h) 
        {
            _a = a;
            _b = b;
            _c = c;
            _d = d;
            _h = h;
        }

        public override decimal CalcularArea() => ((_a + _b) * _h) / 2;

        public override decimal CalcularPerimetro() => (_a + _b + _c + _d);
    }
}
