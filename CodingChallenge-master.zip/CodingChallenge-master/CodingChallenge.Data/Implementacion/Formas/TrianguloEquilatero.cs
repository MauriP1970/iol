﻿using CodingChallenge.Data.Interfases;
using System;

namespace CodingChallenge.Data.Implementacion.Formas
{
    public class TrianguloEquilatero : BaseFormaGeometrica
    {
        private readonly decimal _lado;

        public TrianguloEquilatero(decimal ancho) 
        {
            _lado = ancho;
        }

        public override decimal CalcularArea() => ((decimal)Math.Sqrt(3) / 4) * _lado * _lado;

        public override decimal CalcularPerimetro() => _lado * 3;
    }
}
