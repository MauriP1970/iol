﻿using CodingChallenge.Data.Interfases;

namespace CodingChallenge.Data.Implementacion.Formas
{
    public abstract class BaseFormaGeometrica : IFormaGeometrica
    {
        public string Nombre => this.GetType().Name;

        public abstract decimal CalcularArea();

        public abstract decimal CalcularPerimetro();
    }
}
