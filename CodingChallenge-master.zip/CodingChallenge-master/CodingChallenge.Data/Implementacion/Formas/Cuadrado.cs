﻿using CodingChallenge.Data.Interfases;

namespace CodingChallenge.Data.Implementacion.Formas
{
    public class Cuadrado : BaseFormaGeometrica
    {
        private readonly decimal _lado;

        public Cuadrado(decimal ancho)
        {
            _lado = ancho;
        }

        public override decimal CalcularArea() => _lado * _lado;

        public override decimal CalcularPerimetro() => _lado * 4;
    }
}
