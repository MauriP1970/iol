﻿using CodingChallenge.Data.Interfases;

namespace CodingChallenge.Data.Implementacion.Formas
{
    public class Rectangulo : BaseFormaGeometrica
    {
        private readonly decimal _l;
        private readonly decimal _w;

        public Rectangulo(decimal l, decimal w)
        {
            _l = l;
            _w = w;
        }

        public override decimal CalcularArea() => _l * _w;

        public  override decimal CalcularPerimetro() => 2 * (_l + _w);
    }
}
