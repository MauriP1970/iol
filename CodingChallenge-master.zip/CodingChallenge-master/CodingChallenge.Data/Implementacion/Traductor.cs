﻿using CodingChallenge.Data.Interfases;
using System;
using System.IO;
using System.Resources;

namespace CodingChallenge.Data.Implementacion
{
    public class Traductor : ITraductor
    {
        public string TraducirForma(string nombreForma, int cantidad, string idioma)
        {
            var archivoRecursos = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "Recursos", $"Traducciones_Formas_{idioma}.resx");

            var traduccion = string.Empty;

            using (ResXResourceSet resxSet = new ResXResourceSet(archivoRecursos))
            {
                var idRecurso = ObtenerIdRecurso(nombreForma, cantidad);
                traduccion = resxSet.GetString(idRecurso);
            }

            return traduccion;
        }

        public string TraducirReporte(string nombre, string idioma)
        {
            var archivoRecursos = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "Recursos", $"Traducciones_Reporte_{idioma}.resx");

            var traduccion = string.Empty;

            using (ResXResourceSet resxSet = new ResXResourceSet(archivoRecursos))
            {
                traduccion = resxSet.GetString(nombre);
            }

            return traduccion;
        }

        private string ObtenerIdRecurso(string nombreForma, int cantidad)
        {
            var idRecurso = $"{nombreForma}";

            if (cantidad > 1)
                idRecurso = $"{idRecurso}_plus";

            return idRecurso;
        }
    }
}
