﻿/*
 * Para agregar una nueva forma:
 *  1 - agregar una nueva clase en CodingChallenge.Data.Implementacion.Formas que herede de BaseFormaGeometrica
 *  2 - sobreescribir los metodos CalcularArea y CalcularPerimetro
 *  3 - crear una nueva entrada en los archivos de recursos (Traducciones_Formas_es y Traducciones_Formas_en) donde el nombre correnponde con el nombre de la nueva clase
 *  4 - crear una nueva entrada en los archivos de recursos (Traducciones_Formas_es y Traducciones_Formas_en) donde el nombre correponde con el nombre de la nueva clase mas "_plus", el cual contendrá el nombre plularizado
 * */

/*
 * Para agregar un nuevo idioma:
 *  1 - agregar un nuevo archivo de recursos cuyo nombre debe ser Traducciones_Formas_{abreviatura idioma)
 *  2 - los nombres de los recursos deben ser los mismos que se utilizan en los otros archivos de recursos
 *  3 - agregar una nueva entrada en la clase Idiomas.cs
 * */

using CodingChallenge.Data.Interfases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodingChallenge.Data.Implementacion
{
    public class Reporte : IReporte
    {
        private ITraductor _traductor;
        private string _idioma;

        public Reporte(ITraductor traductor)
        {
            _traductor = traductor;
        }

        public string Imprimir(List<IFormaGeometrica> formas, string idioma)
        {
            _idioma = idioma;

            try
            {
                var sb = new StringBuilder();

                if (!formas.Any())
                {
                    sb.Append(_traductor.TraducirReporte(ReporteIdRecursos.Lista_Vacia, _idioma));
                }
                else
                {
                    sb.Append(_traductor.TraducirReporte(ReporteIdRecursos.Cabecera, _idioma));

                    // obtener totales
                    var totales = formas.GroupBy(f => f.Nombre)
                        .Select(
                            g => new Totales
                            {
                                Tipo = g.Key,
                                Total = g.Count(),
                                TotalArea = g.Sum(t => t.CalcularArea()),
                                TotalPerimetro = g.Sum(t => t.CalcularPerimetro())
                            }
                        ).ToList();

                    // imprimir lineas
                    totales.ForEach(t => sb.Append(ObtenerLinea(t.Total, t.TotalArea, t.TotalPerimetro, t.Tipo)));

                    // imprimir footer
                    sb.Append(ObtenerFooter(totales));
                }

                return sb.ToString();
            }
            catch(Exception ex)
            {
                return $"Error al generar reporte: {ex.Message}";
            }
            
        }

        private string ObtenerLinea(int cantidad, decimal area, decimal perimetro, string nombreForma)
        {
            if (cantidad > 0)
            {
                var nombreFormaTraducido = _traductor.TraducirForma(nombreForma, cantidad, _idioma);
                var nombreArea = _traductor.TraducirReporte(ReporteIdRecursos.Area, _idioma);
                var nombrePerimetro = _traductor.TraducirReporte(ReporteIdRecursos.Perimetro, _idioma);

                return $"{cantidad} {nombreFormaTraducido} | {nombreArea} {area:#.##} | {nombrePerimetro} {perimetro:#.##} <br/>";
            }

            return string.Empty;
        }

        private string ObtenerFooter(List<Totales> totales)
        {
            var sb = new StringBuilder();

            sb.Append($"{_traductor.TraducirReporte(ReporteIdRecursos.Footer_Total, _idioma)}:<br/>");

            var totalFormas = totales.Sum(t => t.Total);
            sb.Append($"{totalFormas} {_traductor.TraducirReporte(ReporteIdRecursos.Footer_Formas, _idioma)}");

            var totalPerimetro = totales.Sum(t => t.TotalPerimetro);
            sb.Append($" {_traductor.TraducirReporte(ReporteIdRecursos.Perimetro, _idioma)} {totalPerimetro.ToString("#.##")}");

            var totalArea = totales.Sum(t => t.TotalArea);
            sb.Append($" {_traductor.TraducirReporte(ReporteIdRecursos.Area, _idioma)} {totalArea.ToString("#.##")}");

            return sb.ToString();
        }
    }
}
