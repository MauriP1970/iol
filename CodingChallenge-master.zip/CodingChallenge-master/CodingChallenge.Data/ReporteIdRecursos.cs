﻿namespace CodingChallenge.Data
{
    /// <summary>
    /// Almacena los diferentes nombre de recursos del archivo Traducciones_Reporte
    /// </summary>
    public static class ReporteIdRecursos
    {
        public static readonly string Cabecera = "HEADER";
        public static readonly string Footer_Total = "FOOTER_TOTAL";
        public static readonly string Footer_Formas = "FOOTER_FORMAS";
        public static readonly string Perimetro = "PERIMETRO";
        public static readonly string Area = "AREA";
        public static readonly string Lista_Vacia = "LISTA_VACIA";
    }
}
