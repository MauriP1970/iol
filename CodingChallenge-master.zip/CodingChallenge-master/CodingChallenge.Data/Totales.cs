﻿namespace CodingChallenge.Data
{
    public class Totales
    {
        public string Tipo { get; set; }
        public int Total { get; set; }
        public decimal TotalArea { get; set; }
        public decimal TotalPerimetro { get; set; }
    }
}
